Yes read me!!!!! Ok so you're reading this right? Of course you are... anyways rename this to ".gitignore" if you don't want to die... OK?!?!??!?!

TECH PART:
If you want to bot to run stuff your token in it, this is some pretty basic shit, you have to replace the "TOKEN HERE" parts and then change the prefix if you like OK!?!?!?!

Yeah that's all don't stay tuned for 2.0...



Have fun :D