#KrauferBot By KablesMC!
#DO NOT DELETE .gitignore!!!!


import discord
from discord.ext import commands
from discord.ext.commands import has_permissions, MissingPermissions

import os
import json

if os.path.exists(os.getcwd() + "/config.json"):
    with open ("./config.json") as f:
      configData = json.load(f)
  
else:
  configTemplate = {"Token": "", "Prefix": "k "}
  with open(os.getcwd() + "/config.json") as f:
    json.dump(configTemplate, f)

token = configData["TOKEN HERE"]


bot = commands.Bot(command_prefix="k ")
bot.remove_command("help")

#BOT

@bot.event
async def on_ready():
  print("BOT ONLINE :)")


@bot.command(description="Test the bot")
@commands.has_permissions(send_messages=True)
async def initest(ctx):
  await ctx.send(f"bot is functional")


  await ctx.message.delete()
  await ctx.author.send(embed=embed)

@bot.command()
async def commands(ctx):

  embed=discord.Embed(title="HELP")
  embed.add_field(name="Userinfo", value="Gets information about the specified user", inline=True)
  embed.add_field(name="MUTE", value="Mutes the specified User", inline=True)
  embed.add_field(name="UNMUTE", value="Unmutes the specified User", inline=True)
  embed.add_field(name="BAN", value="Banishes the specified User", inline=True)
  embed.add_field(name="UNBAN", value="Unbanishes the specified User", inline=True)
  embed.add_field(name="KICK", value="Kicks the specified User", inline=True)
  embed.add_field(name="USERINFO", value="Gets information about a specified user", inline=True)
  embed.add_field(name="SELFINFO", value="Gets information about yourself", inline=True)

  await ctx.message.delete()
  await ctx.author.send(embed=embed)

 
@bot.command(description="Gets the information of a user")
async def userinfo(ctx, member: discord.Member):
  user = member
    
  embed=discord.Embed(title="USER INFO", description="Information retrieved about searched user", colour=user.colour)
  embed.set_thumbnail(url=user.avatar_url)
  embed.add_field(name="NAME", value=user.name, inline=True)
  embed.add_field(name="NICKNAME", value=user.nick, inline=True)
  embed.add_field(name="ID", value=user.id, inline=True)
  embed.add_field(name="AGE", 
  value=user.created_at, inline=True)
  embed.add_field(name="TOP ROLE", 
  value=user.top_role.name, inline=True)
  


  await ctx.send(embed=embed)

@bot.command(description="Gets your information")
async def selfinfo(ctx):
  user = ctx.author
    
  embed=discord.Embed(title="USER INFO", description="Information retrieved about searched user", colour=user.colour)
  embed.set_thumbnail(url=user.avatar_url)
  embed.add_field(name="NAME", value=user.name, inline=True)
  embed.add_field(name="NICKNAME", value=user.nick, inline=True)
  embed.add_field(name="ID", value=user.id, inline=True)
  embed.add_field(name="AGE", 
  value=user.created_at, inline=True)
  embed.add_field(name="TOP ROLE", 
  value=user.top_role.name, inline=True)

  await ctx.send(embed=embed)


@bot.command(description="Augment bots activity status")
@has_permissions(administrator=True)
async def activity(ctx, *, activity):
  await bot.change_presence(activity=discord.Game(activity))
  await ctx.send(f"Changed activity to {activity}")
  

@bot.command(description="Mutes a user")
@has_permissions(manage_messages=True)
async def mute(ctx, member: discord.Member, *, reason=None):
  guild = ctx.guild
  mutedRole = discord.utils.get(guild.roles, name = "muted")
  
  if not mutedRole:
    mutedRole = await guild.create_role(name = "muted")

    for channel in guild.channels:
      await channel.set_permissions(mutedRole, speak=False, send_messages=False, read_message_history=False)

  await member.add_roles(mutedRole, reason=reason)
  await ctx.send(f"Muted {member.mention} for reason: {reason}")  

@bot.command(description= "Unmutes a user")
@has_permissions(manage_messages=True)
async def unmute(ctx, member: discord.Member):
  mutedRole = discord.utils.get(ctx.guild.roles, name = "muted")
  
  await member.remove_roles(mutedRole)
  await ctx.send(f"Unmuted {member.mention}")

@bot.command(description="Banishes the desired member")
@has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):

  await member.ban(reason=reason)
  await ctx.send(f"{member.mention} was banished for: {reason}")

@bot.command(description="Unbanishes the desired member")
@has_permissions(ban_members=True)
async def unban(ctx, *, member):
  bannedUsers = await ctx.guild.bans()
  name, discriminator = member.split("#")

  for ban in bannedUsers:
    user = ban.user

    if (user.name, user.discriminator) == (name, discriminator):
      await ctx.guild.unban(user)
      await ctx.send(f"{user} was unbanished")



@bot.command(description="Kicks the desired member")
@has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
  await member.kick(reason=reason)
  await ctx.send(f"{member.mention} was kicked for: {reason}")


#NUKE BOT SECTION
#indev by kablesmc

bot.run("token")
